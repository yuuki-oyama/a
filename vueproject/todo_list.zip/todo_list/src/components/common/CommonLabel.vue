<template>
    <label>{{ labelData }}</label>
</template>

<script>
export default {
    props: {
        labelData: String,
    },
};
</script>

<style></style>
